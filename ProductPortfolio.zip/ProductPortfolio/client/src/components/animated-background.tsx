export default function AnimatedBackground() {
  return (
    <div className="fixed inset-0 z-0">
      <div className="absolute inset-0 bg-gradient-radial"></div>
      
      <div className="particle w-2 h-2 top-10 left-10 animate-float"></div>
      <div 
        className="particle w-1 h-1 top-1/4 right-1/4 animate-float" 
        style={{ animationDelay: '2s' }}
      ></div>
      <div 
        className="particle w-3 h-3 bottom-1/3 left-1/3 animate-float" 
        style={{ animationDelay: '4s' }}
      ></div>
      <div 
        className="particle w-1.5 h-1.5 top-1/2 right-1/3 animate-float" 
        style={{ animationDelay: '6s' }}
      ></div>
      <div 
        className="particle w-2 h-2 top-3/4 left-1/4 animate-float" 
        style={{ animationDelay: '1s' }}
      ></div>
      <div 
        className="particle w-1 h-1 bottom-1/4 right-1/4 animate-float" 
        style={{ animationDelay: '3s' }}
      ></div>
    </div>
  );
}
