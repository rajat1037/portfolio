import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { usePortfolio } from "@/hooks/use-portfolio";
import EditableText from "@/components/editable-text";
import { insertContactMessageSchema } from "@shared/schema";
import { Mail, Phone, MapPin, Linkedin, Github, FileText, Briefcase } from "lucide-react";
import { z } from "zod";

type ContactFormData = z.infer<typeof insertContactMessageSchema>;

export default function ContactSection() {
  const { data: portfolio, isLoading } = usePortfolio();
  const { toast } = useToast();
  
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm<ContactFormData>({
    resolver: zodResolver(insertContactMessageSchema)
  });

  const contactMutation = useMutation({
    mutationFn: (data: ContactFormData) => apiRequest("POST", "/api/contact", data),
    onSuccess: () => {
      toast({
        title: "Message sent successfully!",
        description: "Thank you for reaching out. I'll get back to you soon.",
      });
      reset();
    },
    onError: () => {
      toast({
        title: "Failed to send message",
        description: "Please try again later or contact me directly.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: ContactFormData) => {
    contactMutation.mutate(data);
  };

  if (isLoading || !portfolio) {
    return (
      <section className="py-24 px-6">
        <div className="animate-pulse text-center">Loading contact section...</div>
      </section>
    );
  }

  return (
    <section id="contact" className="py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-gradient">Let's Connect</h2>
          <p className="text-xl text-gray-300">
            Ready to bring your next product vision to life? Let's discuss how we can work together.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          <div className="glass rounded-2xl p-8">
            <h3 className="text-2xl font-semibold mb-6 text-electric-blue">Send a Message</h3>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div>
                <Label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                  Your Name
                </Label>
                <Input
                  id="name"
                  {...register("name")}
                  className="w-full px-4 py-3 bg-dark-panel border border-gray-600 rounded-lg focus:border-electric-blue focus:outline-none transition-colors"
                  placeholder="John Doe"
                />
                {errors.name && (
                  <p className="text-red-400 text-sm mt-1">{errors.name.message}</p>
                )}
              </div>
              
              <div>
                <Label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                  Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  {...register("email")}
                  className="w-full px-4 py-3 bg-dark-panel border border-gray-600 rounded-lg focus:border-electric-blue focus:outline-none transition-colors"
                  placeholder="john@example.com"
                />
                {errors.email && (
                  <p className="text-red-400 text-sm mt-1">{errors.email.message}</p>
                )}
              </div>
              
              <div>
                <Label htmlFor="subject" className="block text-sm font-medium text-gray-300 mb-2">
                  Subject
                </Label>
                <Input
                  id="subject"
                  {...register("subject")}
                  className="w-full px-4 py-3 bg-dark-panel border border-gray-600 rounded-lg focus:border-electric-blue focus:outline-none transition-colors"
                  placeholder="Project Collaboration"
                />
                {errors.subject && (
                  <p className="text-red-400 text-sm mt-1">{errors.subject.message}</p>
                )}
              </div>
              
              <div>
                <Label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                  Message
                </Label>
                <Textarea
                  id="message"
                  rows={4}
                  {...register("message")}
                  className="w-full px-4 py-3 bg-dark-panel border border-gray-600 rounded-lg focus:border-electric-blue focus:outline-none transition-colors resize-none"
                  placeholder="Tell me about your project..."
                />
                {errors.message && (
                  <p className="text-red-400 text-sm mt-1">{errors.message.message}</p>
                )}
              </div>
              
              <Button 
                type="submit" 
                disabled={contactMutation.isPending}
                className="w-full px-8 py-4 bg-gradient-to-r from-electric-blue to-neon-purple rounded-lg font-semibold hover:shadow-lg hover:shadow-electric-blue/25 transition-all transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {contactMutation.isPending ? "Sending..." : "Send Message"}
              </Button>
            </form>
          </div>

          <div className="space-y-8">
            <div className="glass rounded-2xl p-8">
              <h3 className="text-2xl font-semibold mb-6 text-electric-blue">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-electric-blue/20 rounded-full flex items-center justify-center">
                    <Mail className="h-5 w-5 text-electric-blue" />
                  </div>
                  <div>
                    <div className="font-medium">
                      <EditableText
                        field="contactEmail"
                        value={portfolio.contactEmail}
                        className=""
                        element="span"
                      />
                    </div>
                    <div className="text-sm text-gray-400">Email</div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-neon-purple/20 rounded-full flex items-center justify-center">
                    <Phone className="h-5 w-5 text-neon-purple" />
                  </div>
                  <div>
                    <div className="font-medium">
                      <EditableText
                        field="contactPhone"
                        value={portfolio.contactPhone}
                        className=""
                        element="span"
                      />
                    </div>
                    <div className="text-sm text-gray-400">Phone</div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-neon-cyan/20 rounded-full flex items-center justify-center">
                    <MapPin className="h-5 w-5 text-neon-cyan" />
                  </div>
                  <div>
                    <div className="font-medium">
                      <EditableText
                        field="contactLocation"
                        value={portfolio.contactLocation}
                        className=""
                        element="span"
                      />
                    </div>
                    <div className="text-sm text-gray-400">Location</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="glass rounded-2xl p-8">
              <h3 className="text-2xl font-semibold mb-6 text-electric-blue">Professional Links</h3>
              <div className="grid grid-cols-2 gap-4">
                <Button
                  variant="ghost"
                  className="p-4 bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg flex items-center space-x-3 hover:transform hover:scale-105 transition-all"
                  onClick={() => window.open(portfolio.socialLinks.linkedin, '_blank')}
                >
                  <Linkedin className="h-5 w-5" />
                  <span className="font-medium">LinkedIn</span>
                </Button>
                
                <Button
                  variant="ghost"
                  className="p-4 bg-gradient-to-r from-gray-700 to-gray-800 rounded-lg flex items-center space-x-3 hover:transform hover:scale-105 transition-all"
                  onClick={() => window.open(portfolio.socialLinks.github, '_blank')}
                >
                  <Github className="h-5 w-5" />
                  <span className="font-medium">GitHub</span>
                </Button>
                
                <Button
                  variant="ghost"
                  className="p-4 bg-gradient-to-r from-red-600 to-red-700 rounded-lg flex items-center space-x-3 hover:transform hover:scale-105 transition-all"
                  onClick={() => window.open(portfolio.socialLinks.resume, '_blank')}
                >
                  <FileText className="h-5 w-5" />
                  <span className="font-medium">Resume</span>
                </Button>
                
                <Button
                  variant="ghost"
                  className="p-4 bg-gradient-to-r from-purple-600 to-purple-700 rounded-lg flex items-center space-x-3 hover:transform hover:scale-105 transition-all"
                  onClick={() => window.open(portfolio.socialLinks.portfolio, '_blank')}
                >
                  <Briefcase className="h-5 w-5" />
                  <span className="font-medium">Portfolio</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
