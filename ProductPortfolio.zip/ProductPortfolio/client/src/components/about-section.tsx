import EditableText from "@/components/editable-text";
import { usePortfolio } from "@/hooks/use-portfolio";

export default function AboutSection() {
  const { data: portfolio, isLoading } = usePortfolio();

  if (isLoading || !portfolio) {
    return (
      <section className="py-24 px-6">
        <div className="animate-pulse text-center">Loading about section...</div>
      </section>
    );
  }

  return (
    <section id="about" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold mb-8 text-gradient">About Me</h2>
            <div className="space-y-6 text-lg text-gray-300">
              <p>
                <EditableText
                  field="aboutBio1"
                  value={portfolio.aboutBio1}
                  className=""
                  element="span"
                />
              </p>
              <p>
                <EditableText
                  field="aboutBio2"
                  value={portfolio.aboutBio2}
                  className=""
                  element="span"
                />
              </p>
            </div>
            
            <div className="mt-12">
              <h3 className="text-2xl font-semibold mb-6 text-electric-blue">Core Skills</h3>
              <div className="space-y-4">
                {portfolio.skills.map((skill, index) => (
                  <div key={index} className="skill-item">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">{skill.name}</span>
                      <span className="text-sm text-gray-400">{skill.percentage}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-electric-blue to-neon-purple h-2 rounded-full transition-all duration-1000" 
                        style={{ width: `${skill.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="glass rounded-2xl p-6 transform hover:scale-105 transition-transform">
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=1000" 
                alt="Professional headshot" 
                className="rounded-xl w-full h-auto" 
              />
            </div>
            
            <div className="absolute -top-6 -right-6 glass rounded-xl p-4 transform rotate-6 hover:rotate-0 transition-transform">
              <div className="text-center">
                <div className="text-2xl font-bold text-electric-blue">
                  <EditableText
                    field="stats.projects"
                    value={portfolio.stats.projects}
                    className=""
                    element="span"
                  />
                </div>
                <div className="text-sm text-gray-400">Projects</div>
              </div>
            </div>
            
            <div className="absolute -bottom-6 -left-6 glass rounded-xl p-4 transform -rotate-6 hover:rotate-0 transition-transform">
              <div className="text-center">
                <div className="text-2xl font-bold text-neon-purple">
                  <EditableText
                    field="stats.experience"
                    value={portfolio.stats.experience}
                    className=""
                    element="span"
                  />
                </div>
                <div className="text-sm text-gray-400">Years Exp</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
