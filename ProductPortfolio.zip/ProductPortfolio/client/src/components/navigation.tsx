import { Button } from "@/components/ui/button";
import { useEditMode } from "@/hooks/use-edit-mode";
import { Edit, Save } from "lucide-react";

export default function Navigation() {
  const { isEditMode, toggleEditMode } = useEditMode();

  const scrollToSection = (sectionId: string) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <nav className="fixed top-6 left-1/2 transform -translate-x-1/2 z-50 glass rounded-full px-8 py-4 pt-[10px] pb-[10px]">
        <div className="flex space-x-8">
          <button 
            onClick={() => scrollToSection('hero')}
            className="text-sm font-medium hover:text-electric-blue transition-colors"
          >
            Home
          </button>
          <button 
            onClick={() => scrollToSection('about')}
            className="text-sm font-medium hover:text-electric-blue transition-colors"
          >
            About
          </button>
          <button 
            onClick={() => scrollToSection('projects')}
            className="text-sm font-medium hover:text-electric-blue transition-colors"
          >
            Projects
          </button>
          <button 
            onClick={() => scrollToSection('contact')}
            className="text-sm font-medium hover:text-electric-blue transition-colors"
          >
            Contact
          </button>
        </div>
      </nav>
      <Button
        variant="ghost"
        size="icon"
        onClick={toggleEditMode}
        className={`fixed top-6 right-6 z-50 glass rounded-full p-3 transition-all ${
          isEditMode 
            ? 'hover:bg-neon-purple/20' 
            : 'hover:bg-electric-blue/20'
        }`}
      >
        {isEditMode ? (
          <Save className={`h-5 w-5 text-neon-purple`} />
        ) : (
          <Edit className="h-5 w-5 text-electric-blue" />
        )}
      </Button>
      {isEditMode && (
        <div className="fixed bottom-6 left-6 glass rounded-lg p-4 text-sm z-50 max-w-xs">
          <div className="text-electric-blue font-semibold mb-1">Edit Mode Active</div>
          <div className="text-gray-300">
            Click on any highlighted text to edit. Changes are saved automatically.
          </div>
        </div>
      )}
    </>
  );
}
