import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { usePortfolio } from "@/hooks/use-portfolio";
import { ExternalLink, Github, Smartphone, Monitor, Cloud } from "lucide-react";

export default function ProjectsSection() {
  const { data: portfolio, isLoading } = usePortfolio();
  const [activeFilter, setActiveFilter] = useState("all");

  if (isLoading || !portfolio) {
    return (
      <section className="py-24 px-6 bg-dark-panel/30">
        <div className="animate-pulse text-center">Loading projects...</div>
      </section>
    );
  }

  const filteredProjects = activeFilter === "all" 
    ? portfolio.projects 
    : portfolio.projects.filter(project => project.category === activeFilter);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'mobile':
        return <Smartphone className="h-4 w-4" />;
      case 'web':
        return <Monitor className="h-4 w-4" />;
      case 'saas':
        return <Cloud className="h-4 w-4" />;
      default:
        return <Monitor className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'mobile':
        return 'text-neon-purple bg-neon-purple/20';
      case 'web':
        return 'text-electric-blue bg-electric-blue/20';
      case 'saas':
        return 'text-neon-cyan bg-neon-cyan/20';
      default:
        return 'text-electric-blue bg-electric-blue/20';
    }
  };

  return (
    <section id="projects" className="py-24 px-6 bg-dark-panel/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-gradient">Featured Projects</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            A collection of products I've helped bring to life, from concept to launch
          </p>
        </div>

        <div className="flex justify-center mb-12">
          <div className="glass rounded-full p-2 flex flex-wrap gap-2">
            {[
              { key: 'all', label: 'All' },
              { key: 'mobile', label: 'Mobile' },
              { key: 'web', label: 'Web' },
              { key: 'saas', label: 'SaaS' }
            ].map(filter => (
              <Button
                key={filter.key}
                variant="ghost"
                className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                  activeFilter === filter.key 
                    ? 'bg-electric-blue text-black' 
                    : 'hover:bg-white/10'
                }`}
                onClick={() => setActiveFilter(filter.key)}
              >
                {filter.label}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <div 
              key={project.id} 
              className="glass rounded-2xl p-6 hover:transform hover:scale-105 transition-all animate-slide-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <img 
                src={project.imageUrl} 
                alt={project.title}
                className="w-full h-48 object-cover rounded-xl mb-4" 
              />
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-semibold">{project.title}</h3>
                  <Badge className={`${getCategoryColor(project.category)} flex items-center gap-1`}>
                    {getCategoryIcon(project.category)}
                    {project.category.charAt(0).toUpperCase() + project.category.slice(1)}
                  </Badge>
                </div>
                <p className="text-gray-400 text-sm">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, tagIndex) => (
                    <Badge key={tagIndex} variant="secondary" className="bg-gray-700 text-gray-300">
                      {tag}
                    </Badge>
                  ))}
                </div>
                <div className="flex justify-between items-center pt-2">
                  {project.caseStudyUrl && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-electric-blue hover:text-white transition-colors p-0 h-auto"
                      onClick={() => window.open(project.caseStudyUrl, '_blank')}
                    >
                      <ExternalLink className="h-4 w-4 mr-1" />
                      View Case Study
                    </Button>
                  )}
                  {project.githubUrl && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-gray-400 hover:text-white transition-colors p-0 h-auto"
                      onClick={() => window.open(project.githubUrl, '_blank')}
                    >
                      <Github className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
