import { Button } from "@/components/ui/button";
import EditableText from "@/components/editable-text";
import { usePortfolio } from "@/hooks/use-portfolio";
import { Github, Linkedin, Twitter } from "lucide-react";

export default function HeroSection() {
  const { data: portfolio, isLoading } = usePortfolio();

  if (isLoading) {
    return (
      <section className="min-h-screen flex items-center justify-center relative">
        <div className="animate-pulse text-electric-blue">Loading...</div>
      </section>
    );
  }

  if (!portfolio) {
    return (
      <section className="min-h-screen flex items-center justify-center relative">
        <div className="text-red-400">Failed to load portfolio data</div>
      </section>
    );
  }

  const scrollToProjects = () => {
    document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="hero" className="min-h-screen flex items-center justify-center relative">
      <div className="max-w-6xl mx-auto px-6 text-center">
        <div className="mb-8">
          <span className="inline-block px-4 py-2 rounded-full bg-neon-purple/20 text-neon-purple text-sm font-mono mb-6">
            Product Manager
          </span>
        </div>
        
        <h1 className="text-6xl md:text-8xl font-bold mb-6">
          <EditableText
            field="heroName"
            value={portfolio.heroName}
            className="text-gradient"
            element="span"
          />
        </h1>
        
        <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
          <EditableText
            field="heroTagline"
            value={portfolio.heroTagline}
            className=""
            element="span"
          />
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <Button 
            onClick={scrollToProjects}
            className="px-8 py-4 bg-gradient-to-r from-electric-blue to-neon-purple rounded-full font-semibold hover:shadow-lg hover:shadow-electric-blue/25 transition-all transform hover:scale-105 animate-glow"
          >
            View My Work
          </Button>
          <Button 
            variant="outline"
            className="px-8 py-4 glass rounded-full font-semibold hover:bg-white/10 transition-all border-white/20"
            onClick={() => window.open(portfolio.socialLinks.resume, '_blank')}
          >
            Download Resume
          </Button>
        </div>
        
        <div className="flex justify-center space-x-6">
          <Button
            variant="ghost"
            size="icon"
            className="w-12 h-12 glass rounded-full hover:bg-electric-blue/20 transition-all"
            onClick={() => window.open(portfolio.socialLinks.linkedin, '_blank')}
          >
            <Linkedin className="h-6 w-6" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="w-12 h-12 glass rounded-full hover:bg-electric-blue/20 transition-all"
            onClick={() => window.open(portfolio.socialLinks.github, '_blank')}
          >
            <Github className="h-6 w-6" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="w-12 h-12 glass rounded-full hover:bg-electric-blue/20 transition-all"
            onClick={() => window.open('https://twitter.com', '_blank')}
          >
            <Twitter className="h-6 w-6" />
          </Button>
        </div>
      </div>
    </section>
  );
}
