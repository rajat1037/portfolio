import { useState, useRef, useEffect } from "react";
import { useEditMode } from "@/hooks/use-edit-mode";
import { usePortfolio } from "@/hooks/use-portfolio";

interface EditableTextProps {
  field: string;
  value: string;
  className?: string;
  element?: 'span' | 'div' | 'h1' | 'h2' | 'h3' | 'p';
}

export default function EditableText({ 
  field, 
  value, 
  className = "", 
  element = 'span' 
}: EditableTextProps) {
  const { isEditMode } = useEditMode();
  const { updateField } = usePortfolio();
  const [isEditing, setIsEditing] = useState(false);
  const [localValue, setLocalValue] = useState(value);
  const elementRef = useRef<HTMLElement>(null);
  
  useEffect(() => {
    setLocalValue(value);
  }, [value]);

  const handleClick = () => {
    if (isEditMode && !isEditing) {
      setIsEditing(true);
    }
  };

  const handleBlur = () => {
    if (isEditing) {
      setIsEditing(false);
      if (localValue !== value) {
        updateField(field, localValue);
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      elementRef.current?.blur();
    }
    if (e.key === 'Escape') {
      setLocalValue(value);
      elementRef.current?.blur();
    }
  };

  const handleInput = (e: React.FormEvent<HTMLElement>) => {
    setLocalValue((e.target as HTMLElement).textContent || '');
  };

  const editModeClasses = isEditMode 
    ? 'edit-indicator cursor-pointer hover:bg-white/5 rounded px-1 transition-colors' 
    : '';
  
  const editingClasses = isEditing 
    ? 'outline outline-2 outline-electric-blue outline-offset-2 bg-dark-panel/50 rounded px-2 py-1' 
    : '';

  const combinedClassName = `${className} ${editModeClasses} ${editingClasses}`.trim();

  const props = {
    ref: elementRef,
    className: combinedClassName,
    onClick: handleClick,
    onBlur: handleBlur,
    onKeyDown: handleKeyDown,
    onInput: handleInput,
    contentEditable: isEditMode && isEditing,
    suppressContentEditableWarning: true,
    children: localValue
  };

  switch (element) {
    case 'div':
      return <div {...props} />;
    case 'h1':
      return <h1 {...props} />;
    case 'h2':
      return <h2 {...props} />;
    case 'h3':
      return <h3 {...props} />;
    case 'p':
      return <p {...props} />;
    default:
      return <span {...props} />;
  }
}
