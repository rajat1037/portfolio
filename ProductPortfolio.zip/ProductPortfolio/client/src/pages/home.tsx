import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import ProjectsSection from "@/components/projects-section";
import ContactSection from "@/components/contact-section";
import Navigation from "@/components/navigation";
import AnimatedBackground from "@/components/animated-background";

export default function Home() {
  return (
    <div className="bg-dark-bg text-white font-sans overflow-x-hidden min-h-screen">
      <AnimatedBackground />
      <Navigation />
      
      <main className="relative z-10">
        <HeroSection />
        <AboutSection />
        <ProjectsSection />
        <ContactSection />
      </main>

      <footer className="py-12 px-6 border-t border-gray-800 relative z-10">
        <div className="max-w-6xl mx-auto text-center">
          <div className="text-gray-400">
            © 2024 Alex Chen. Crafted with passion and innovation.
          </div>
          <div className="mt-4 text-sm text-gray-500">
            This portfolio is fully editable - click the edit button to customize content
          </div>
        </div>
      </footer>
    </div>
  );
}
