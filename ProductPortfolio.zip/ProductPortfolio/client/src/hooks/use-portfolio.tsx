import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { type Portfolio, type InsertPortfolio } from "@shared/schema";

export function usePortfolio() {
  const queryClient = useQueryClient();

  const query = useQuery<Portfolio>({
    queryKey: ["/api/portfolio"],
  });

  const updateMutation = useMutation({
    mutationFn: (data: InsertPortfolio) => apiRequest("PUT", "/api/portfolio", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/portfolio"] });
    },
  });

  const updateField = (field: string, value: any) => {
    if (!query.data) return;

    const updatedData = { ...query.data };
    
    // Handle nested field updates (e.g., "stats.projects")
    if (field.includes('.')) {
      const parts = field.split('.');
      let current: any = updatedData;
      for (let i = 0; i < parts.length - 1; i++) {
        current = current[parts[i]];
      }
      current[parts[parts.length - 1]] = value;
    } else {
      (updatedData as any)[field] = value;
    }

    // Remove the id field for the update request
    const { id, ...updateData } = updatedData;
    updateMutation.mutate(updateData);
  };

  return {
    ...query,
    updateField,
    isUpdating: updateMutation.isPending,
  };
}
