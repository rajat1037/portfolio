import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const portfolio = pgTable("portfolio", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  heroName: text("hero_name").notNull(),
  heroTagline: text("hero_tagline").notNull(),
  aboutBio1: text("about_bio1").notNull(),
  aboutBio2: text("about_bio2").notNull(),
  skills: jsonb("skills").$type<Array<{name: string; percentage: number}>>().notNull(),
  projects: jsonb("projects").$type<Array<{
    id: string;
    title: string;
    description: string;
    category: string;
    tags: string[];
    imageUrl: string;
    caseStudyUrl?: string;
    githubUrl?: string;
  }>>().notNull(),
  contactEmail: text("contact_email").notNull(),
  contactPhone: text("contact_phone").notNull(),
  contactLocation: text("contact_location").notNull(),
  socialLinks: jsonb("social_links").$type<{
    linkedin: string;
    github: string;
    resume: string;
    portfolio: string;
  }>().notNull(),
  stats: jsonb("stats").$type<{
    projects: string;
    experience: string;
  }>().notNull(),
});

export const contactMessages = pgTable("contact_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertPortfolioSchema = createInsertSchema(portfolio).omit({
  id: true,
});

export const insertContactMessageSchema = createInsertSchema(contactMessages).omit({
  id: true,
  createdAt: true,
});

export type InsertPortfolio = z.infer<typeof insertPortfolioSchema>;
export type Portfolio = typeof portfolio.$inferSelect;
export type InsertContactMessage = z.infer<typeof insertContactMessageSchema>;
export type ContactMessage = typeof contactMessages.$inferSelect;
