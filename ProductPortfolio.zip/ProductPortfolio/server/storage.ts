import { type Portfolio, type InsertPortfolio, type ContactMessage, type InsertContactMessage } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getPortfolio(): Promise<Portfolio | undefined>;
  updatePortfolio(portfolio: InsertPortfolio): Promise<Portfolio>;
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getContactMessages(): Promise<ContactMessage[]>;
}

export class MemStorage implements IStorage {
  private portfolio: Portfolio | undefined;
  private contactMessages: Map<string, ContactMessage>;

  constructor() {
    this.contactMessages = new Map();
    // Initialize with default portfolio data
    this.portfolio = {
      id: randomUUID(),
      heroName: "Alex Chen",
      heroTagline: "Crafting digital experiences that bridge the gap between user needs and business goals through data-driven innovation",
      aboutBio1: "I'm a passionate Product Manager with 5+ years of experience transforming complex problems into elegant digital solutions. My approach combines analytical thinking with creative problem-solving to deliver products that users love and businesses value.",
      aboutBio2: "Currently leading product initiatives at TechCorp, I specialize in SaaS platforms, mobile applications, and data-driven decision making. I believe in building products that create meaningful impact while maintaining exceptional user experience.",
      skills: [
        { name: "Product Strategy", percentage: 95 },
        { name: "Data Analysis", percentage: 88 },
        { name: "User Research", percentage: 92 },
        { name: "Agile/Scrum", percentage: 90 }
      ],
      projects: [
        {
          id: "1",
          title: "E-commerce Analytics Platform",
          description: "Led the development of a comprehensive analytics dashboard that increased merchant engagement by 40%",
          category: "web",
          tags: ["Analytics", "Dashboard", "React"],
          imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
          caseStudyUrl: "#",
          githubUrl: "#"
        },
        {
          id: "2",
          title: "FitTrack Mobile App",
          description: "Designed and launched a fitness tracking app with 100K+ downloads and 4.8-star rating",
          category: "mobile",
          tags: ["Fitness", "React Native", "UX"],
          imageUrl: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
        },
        {
          id: "3",
          title: "ProjectFlow SaaS",
          description: "Built a project management platform that streamlined workflows for 500+ teams globally",
          category: "saas",
          tags: ["SaaS", "Collaboration", "Vue.js"],
          imageUrl: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
        },
        {
          id: "4",
          title: "InvestSmart Platform",
          description: "Launched an investment platform that democratized trading for 50K+ retail investors",
          category: "web",
          tags: ["Fintech", "Trading", "Angular"],
          imageUrl: "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
        },
        {
          id: "5",
          title: "ConnectHub Social",
          description: "Created a community-focused social app with innovative features that boosted engagement by 65%",
          category: "mobile",
          tags: ["Social", "Community", "Flutter"],
          imageUrl: "https://images.unsplash.com/photo-1611262588024-d12430b98920?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
        },
        {
          id: "6",
          title: "CRM Analytics Suite",
          description: "Developed a comprehensive CRM solution that increased sales team productivity by 35%",
          category: "saas",
          tags: ["CRM", "Sales", "Node.js"],
          imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
        }
      ],
      contactEmail: "alex.chen@email.com",
      contactPhone: "+1 (555) 123-4567",
      contactLocation: "San Francisco, CA",
      socialLinks: {
        linkedin: "https://linkedin.com/in/alexchen",
        github: "https://github.com/alexchen",
        resume: "/resume.pdf",
        portfolio: "https://alexchen.dev"
      },
      stats: {
        projects: "50+",
        experience: "5+"
      }
    };
  }

  async getPortfolio(): Promise<Portfolio | undefined> {
    return this.portfolio;
  }

  async updatePortfolio(portfolioData: InsertPortfolio): Promise<Portfolio> {
    const updated: Portfolio = {
      id: this.portfolio?.id || randomUUID(),
      ...portfolioData
    };
    this.portfolio = updated;
    return updated;
  }

  async createContactMessage(messageData: InsertContactMessage): Promise<ContactMessage> {
    const id = randomUUID();
    const message: ContactMessage = {
      ...messageData,
      id,
      createdAt: new Date().toISOString()
    };
    this.contactMessages.set(id, message);
    return message;
  }

  async getContactMessages(): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values());
  }
}

export const storage = new MemStorage();
